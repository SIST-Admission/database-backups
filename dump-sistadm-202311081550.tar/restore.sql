--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 14.8 (Ubuntu 14.8-0ubuntu0.22.10.1)
-- Dumped by pg_dump version 14.2

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE sistadm;
--
-- Name: sistadm; Type: DATABASE; Schema: -; Owner: postgres
--

CREATE DATABASE sistadm WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE = 'C.UTF-8';


ALTER DATABASE sistadm OWNER TO postgres;

\connect sistadm

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: public; Type: SCHEMA; Schema: -; Owner: postgres
--

CREATE SCHEMA public;


ALTER SCHEMA public OWNER TO postgres;

--
-- Name: SCHEMA public; Type: COMMENT; Schema: -; Owner: postgres
--

COMMENT ON SCHEMA public IS 'standard public schema';


--
-- Name: academic_details_id_seq; Type: SEQUENCE; Schema: public; Owner: sistadm_write
--

CREATE SEQUENCE public.academic_details_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.academic_details_id_seq OWNER TO sistadm_write;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: academic_details; Type: TABLE; Schema: public; Owner: sistadm_write
--

CREATE TABLE public.academic_details (
    id integer DEFAULT nextval('public.academic_details_id_seq'::regclass) NOT NULL,
    class_10_school_id integer NOT NULL,
    class_12_school_id integer,
    diploma_id integer,
    jee_mains_rank integer DEFAULT 0,
    jee_mains_marks integer DEFAULT 0,
    jee_advanced_rank integer DEFAULT 0,
    jee_advanced_marks integer DEFAULT 0,
    cuet_rank integer DEFAULT 0,
    cuet_marks integer DEFAULT 0,
    merit_score integer
);


ALTER TABLE public.academic_details OWNER TO sistadm_write;

--
-- Name: application_id_seq; Type: SEQUENCE; Schema: public; Owner: sistadm_write
--

CREATE SEQUENCE public.application_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.application_id_seq OWNER TO sistadm_write;

--
-- Name: applications; Type: TABLE; Schema: public; Owner: sistadm_write
--

CREATE TABLE public.applications (
    id integer DEFAULT nextval('public.application_id_seq'::regclass) NOT NULL,
    basic_details_id integer,
    academic_details_id integer,
    payment_id integer,
    application_type character varying(255) DEFAULT 'FRESHER'::character varying NOT NULL,
    application_start_date date DEFAULT CURRENT_DATE NOT NULL,
    status character varying(255) DEFAULT 'NOT SUBMITTED'::character varying NOT NULL
);


ALTER TABLE public.applications OWNER TO sistadm_write;

--
-- Name: basic_details_id_seq; Type: SEQUENCE; Schema: public; Owner: sistadm_write
--

CREATE SEQUENCE public.basic_details_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.basic_details_id_seq OWNER TO sistadm_write;

--
-- Name: basic_details; Type: TABLE; Schema: public; Owner: sistadm_write
--

CREATE TABLE public.basic_details (
    id integer DEFAULT nextval('public.basic_details_id_seq'::regclass) NOT NULL,
    name character varying(255) NOT NULL,
    dob date NOT NULL,
    gender character(10) NOT NULL,
    category character(10) NOT NULL,
    is_coi boolean NOT NULL,
    is_pwd boolean NOT NULL,
    father_name character varying(255) NOT NULL,
    mother_name character varying(255) NOT NULL,
    nationality character varying(255) NOT NULL,
    identity_type character varying(255) NOT NULL,
    identity_number character varying(255) NOT NULL,
    identity_document_id integer NOT NULL,
    signature_document_id integer,
    photo_document_id integer,
    email character varying(255) DEFAULT ''::character varying NOT NULL,
    phone character varying(255) DEFAULT ''::character varying NOT NULL,
    address character varying DEFAULT ''::character varying NOT NULL
);


ALTER TABLE public.basic_details OWNER TO sistadm_write;

--
-- Name: batches; Type: TABLE; Schema: public; Owner: sistadm_write
--

CREATE TABLE public.batches (
    batch_code character varying NOT NULL,
    batch_name character varying(255),
    department_code character varying NOT NULL,
    start_year integer NOT NULL,
    end_year integer NOT NULL
);


ALTER TABLE public.batches OWNER TO sistadm_write;

--
-- Name: class_12_marks_id_seq; Type: SEQUENCE; Schema: public; Owner: sistadm_write
--

CREATE SEQUENCE public.class_12_marks_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.class_12_marks_id_seq OWNER TO sistadm_write;

--
-- Name: class_12_marks; Type: TABLE; Schema: public; Owner: sistadm_write
--

CREATE TABLE public.class_12_marks (
    id integer DEFAULT nextval('public.class_12_marks_id_seq'::regclass) NOT NULL,
    school_id integer NOT NULL,
    marks_obtained integer NOT NULL,
    total_marks integer NOT NULL,
    is_passed boolean NOT NULL,
    subject_name character varying(255) DEFAULT ''::character varying NOT NULL
);


ALTER TABLE public.class_12_marks OWNER TO sistadm_write;

--
-- Name: departments; Type: TABLE; Schema: public; Owner: sistadm_write
--

CREATE TABLE public.departments (
    department_code character varying(4) NOT NULL,
    department_name character varying(255) NOT NULL
);


ALTER TABLE public.departments OWNER TO sistadm_write;

--
-- Name: diploma_id_seq; Type: SEQUENCE; Schema: public; Owner: sistadm_write
--

CREATE SEQUENCE public.diploma_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.diploma_id_seq OWNER TO sistadm_write;

--
-- Name: diploma; Type: TABLE; Schema: public; Owner: sistadm_write
--

CREATE TABLE public.diploma (
    id integer DEFAULT nextval('public.diploma_id_seq'::regclass) NOT NULL,
    college_name character varying(255) NOT NULL,
    department character varying(255) NOT NULL,
    year_of_passing integer NOT NULL,
    cgpa double precision DEFAULT 0.0 NOT NULL,
    document_id integer NOT NULL
);


ALTER TABLE public.diploma OWNER TO sistadm_write;

--
-- Name: diploma_marks_id_seq; Type: SEQUENCE; Schema: public; Owner: sistadm_write
--

CREATE SEQUENCE public.diploma_marks_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.diploma_marks_id_seq OWNER TO sistadm_write;

--
-- Name: documents_id_seq; Type: SEQUENCE; Schema: public; Owner: sistadm_write
--

CREATE SEQUENCE public.documents_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.documents_id_seq OWNER TO sistadm_write;

--
-- Name: documents; Type: TABLE; Schema: public; Owner: sistadm_write
--

CREATE TABLE public.documents (
    id integer DEFAULT nextval('public.documents_id_seq'::regclass) NOT NULL,
    document_name character varying(255) NOT NULL,
    mime_type character varying(255) NOT NULL,
    key character varying(255) NOT NULL,
    is_verified boolean NOT NULL,
    user_id integer,
    file_url character varying(255) DEFAULT NULL::character varying,
    status character varying(255) DEFAULT 'PENDING'::character varying NOT NULL
);


ALTER TABLE public.documents OWNER TO sistadm_write;

--
-- Name: merit_list_id_seq; Type: SEQUENCE; Schema: public; Owner: sistadm_write
--

CREATE SEQUENCE public.merit_list_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.merit_list_id_seq OWNER TO sistadm_write;

--
-- Name: merit_list_student_id_seq; Type: SEQUENCE; Schema: public; Owner: sistadm_write
--

CREATE SEQUENCE public.merit_list_student_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.merit_list_student_id_seq OWNER TO sistadm_write;

--
-- Name: merit_list_students; Type: TABLE; Schema: public; Owner: sistadm_write
--

CREATE TABLE public.merit_list_students (
    id integer DEFAULT nextval('public.merit_list_student_id_seq'::regclass) NOT NULL,
    merit_list_id integer NOT NULL,
    user_id integer NOT NULL,
    submission_id integer NOT NULL,
    total_merit_score integer NOT NULL
);


ALTER TABLE public.merit_list_students OWNER TO sistadm_write;

--
-- Name: merit_lists; Type: TABLE; Schema: public; Owner: sistadm_write
--

CREATE TABLE public.merit_lists (
    id integer DEFAULT nextval('public.merit_list_id_seq'::regclass) NOT NULL,
    department_code character varying NOT NULL,
    batch_code character varying NOT NULL,
    published_date date,
    last_payment_date date,
    is_published boolean DEFAULT false NOT NULL
);


ALTER TABLE public.merit_lists OWNER TO sistadm_write;

--
-- Name: payment_transactions_id_seq; Type: SEQUENCE; Schema: public; Owner: sistadm_write
--

CREATE SEQUENCE public.payment_transactions_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.payment_transactions_id_seq OWNER TO sistadm_write;

--
-- Name: payment_transactions; Type: TABLE; Schema: public; Owner: sistadm_write
--

CREATE TABLE public.payment_transactions (
    id integer DEFAULT nextval('public.payment_transactions_id_seq'::regclass) NOT NULL,
    payment_id integer NOT NULL,
    rp_payment_id character varying(255) NOT NULL,
    amount integer NOT NULL,
    is_success boolean DEFAULT false NOT NULL,
    status character varying(255) NOT NULL,
    metadata text
);


ALTER TABLE public.payment_transactions OWNER TO sistadm_write;

--
-- Name: payments_id_seq; Type: SEQUENCE; Schema: public; Owner: sistadm_write
--

CREATE SEQUENCE public.payments_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.payments_id_seq OWNER TO sistadm_write;

--
-- Name: payments; Type: TABLE; Schema: public; Owner: sistadm_write
--

CREATE TABLE public.payments (
    id integer DEFAULT nextval('public.payments_id_seq'::regclass) NOT NULL,
    amount integer NOT NULL,
    payment_date date DEFAULT CURRENT_DATE NOT NULL,
    payment_mode character varying(255) DEFAULT 'online'::character varying NOT NULL,
    is_paid boolean DEFAULT false NOT NULL,
    rp_order_id character varying(255) NOT NULL,
    status character varying(50) DEFAULT 'created'::character varying
);


ALTER TABLE public.payments OWNER TO sistadm_write;

--
-- Name: school_id_seq; Type: SEQUENCE; Schema: public; Owner: sistadm_write
--

CREATE SEQUENCE public.school_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.school_id_seq OWNER TO sistadm_write;

--
-- Name: school; Type: TABLE; Schema: public; Owner: sistadm_write
--

CREATE TABLE public.school (
    id integer DEFAULT nextval('public.school_id_seq'::regclass) NOT NULL,
    board character varying(255) NOT NULL,
    year_of_passing integer NOT NULL,
    roll_number character varying(255) NOT NULL,
    percentage double precision NOT NULL,
    document_id integer,
    total_marks double precision,
    marks_obtained double precision,
    school_name character varying(255) DEFAULT NULL::character varying
);


ALTER TABLE public.school OWNER TO sistadm_write;

--
-- Name: submission_id_seq; Type: SEQUENCE; Schema: public; Owner: sistadm_write
--

CREATE SEQUENCE public.submission_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.submission_id_seq OWNER TO sistadm_write;

--
-- Name: submissions; Type: TABLE; Schema: public; Owner: sistadm_write
--

CREATE TABLE public.submissions (
    id integer DEFAULT nextval('public.submission_id_seq'::regclass) NOT NULL,
    user_id integer NOT NULL,
    department_code character varying NOT NULL,
    batch_code character varying NOT NULL,
    status character varying(255) NOT NULL,
    is_verified boolean DEFAULT false NOT NULL,
    is_admitted boolean DEFAULT false NOT NULL,
    application_id integer NOT NULL,
    merit_list_id integer,
    payment_id integer
);


ALTER TABLE public.submissions OWNER TO sistadm_write;

--
-- Name: users_id_seq; Type: SEQUENCE; Schema: public; Owner: sistadm_write
--

CREATE SEQUENCE public.users_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.users_id_seq OWNER TO sistadm_write;

--
-- Name: users; Type: TABLE; Schema: public; Owner: sistadm_write
--

CREATE TABLE public.users (
    id integer DEFAULT nextval('public.users_id_seq'::regclass) NOT NULL,
    name character varying(255) NOT NULL,
    email character varying(255) NOT NULL,
    password character varying(255) NOT NULL,
    phone character varying(15) NOT NULL,
    email_verified boolean DEFAULT false NOT NULL,
    phone_verified boolean DEFAULT false NOT NULL,
    role character varying(255) DEFAULT 'STUDENT'::character varying NOT NULL,
    application_id integer,
    is_active boolean DEFAULT true NOT NULL
);


ALTER TABLE public.users OWNER TO sistadm_write;

--
-- Data for Name: academic_details; Type: TABLE DATA; Schema: public; Owner: sistadm_write
--

COPY public.academic_details (id, class_10_school_id, class_12_school_id, diploma_id, jee_mains_rank, jee_mains_marks, jee_advanced_rank, jee_advanced_marks, cuet_rank, cuet_marks, merit_score) FROM stdin;
\.
COPY public.academic_details (id, class_10_school_id, class_12_school_id, diploma_id, jee_mains_rank, jee_mains_marks, jee_advanced_rank, jee_advanced_marks, cuet_rank, cuet_marks, merit_score) FROM '$$PATH$$/3499.dat';

--
-- Data for Name: applications; Type: TABLE DATA; Schema: public; Owner: sistadm_write
--

COPY public.applications (id, basic_details_id, academic_details_id, payment_id, application_type, application_start_date, status) FROM stdin;
\.
COPY public.applications (id, basic_details_id, academic_details_id, payment_id, application_type, application_start_date, status) FROM '$$PATH$$/3504.dat';

--
-- Data for Name: basic_details; Type: TABLE DATA; Schema: public; Owner: sistadm_write
--

COPY public.basic_details (id, name, dob, gender, category, is_coi, is_pwd, father_name, mother_name, nationality, identity_type, identity_number, identity_document_id, signature_document_id, photo_document_id, email, phone, address) FROM stdin;
\.
COPY public.basic_details (id, name, dob, gender, category, is_coi, is_pwd, father_name, mother_name, nationality, identity_type, identity_number, identity_document_id, signature_document_id, photo_document_id, email, phone, address) FROM '$$PATH$$/3492.dat';

--
-- Data for Name: batches; Type: TABLE DATA; Schema: public; Owner: sistadm_write
--

COPY public.batches (batch_code, batch_name, department_code, start_year, end_year) FROM stdin;
\.
COPY public.batches (batch_code, batch_name, department_code, start_year, end_year) FROM '$$PATH$$/3487.dat';

--
-- Data for Name: class_12_marks; Type: TABLE DATA; Schema: public; Owner: sistadm_write
--

COPY public.class_12_marks (id, school_id, marks_obtained, total_marks, is_passed, subject_name) FROM stdin;
\.
COPY public.class_12_marks (id, school_id, marks_obtained, total_marks, is_passed, subject_name) FROM '$$PATH$$/3514.dat';

--
-- Data for Name: departments; Type: TABLE DATA; Schema: public; Owner: sistadm_write
--

COPY public.departments (department_code, department_name) FROM stdin;
\.
COPY public.departments (department_code, department_name) FROM '$$PATH$$/3486.dat';

--
-- Data for Name: diploma; Type: TABLE DATA; Schema: public; Owner: sistadm_write
--

COPY public.diploma (id, college_name, department, year_of_passing, cgpa, document_id) FROM stdin;
\.
COPY public.diploma (id, college_name, department, year_of_passing, cgpa, document_id) FROM '$$PATH$$/3494.dat';

--
-- Data for Name: documents; Type: TABLE DATA; Schema: public; Owner: sistadm_write
--

COPY public.documents (id, document_name, mime_type, key, is_verified, user_id, file_url, status) FROM stdin;
\.
COPY public.documents (id, document_name, mime_type, key, is_verified, user_id, file_url, status) FROM '$$PATH$$/3490.dat';

--
-- Data for Name: merit_list_students; Type: TABLE DATA; Schema: public; Owner: sistadm_write
--

COPY public.merit_list_students (id, merit_list_id, user_id, submission_id, total_merit_score) FROM stdin;
\.
COPY public.merit_list_students (id, merit_list_id, user_id, submission_id, total_merit_score) FROM '$$PATH$$/3512.dat';

--
-- Data for Name: merit_lists; Type: TABLE DATA; Schema: public; Owner: sistadm_write
--

COPY public.merit_lists (id, department_code, batch_code, published_date, last_payment_date, is_published) FROM stdin;
\.
COPY public.merit_lists (id, department_code, batch_code, published_date, last_payment_date, is_published) FROM '$$PATH$$/3510.dat';

--
-- Data for Name: payment_transactions; Type: TABLE DATA; Schema: public; Owner: sistadm_write
--

COPY public.payment_transactions (id, payment_id, rp_payment_id, amount, is_success, status, metadata) FROM stdin;
\.
COPY public.payment_transactions (id, payment_id, rp_payment_id, amount, is_success, status, metadata) FROM '$$PATH$$/3513.dat';

--
-- Data for Name: payments; Type: TABLE DATA; Schema: public; Owner: sistadm_write
--

COPY public.payments (id, amount, payment_date, payment_mode, is_paid, rp_order_id, status) FROM stdin;
\.
COPY public.payments (id, amount, payment_date, payment_mode, is_paid, rp_order_id, status) FROM '$$PATH$$/3501.dat';

--
-- Data for Name: school; Type: TABLE DATA; Schema: public; Owner: sistadm_write
--

COPY public.school (id, board, year_of_passing, roll_number, percentage, document_id, total_marks, marks_obtained, school_name) FROM stdin;
\.
COPY public.school (id, board, year_of_passing, roll_number, percentage, document_id, total_marks, marks_obtained, school_name) FROM '$$PATH$$/3497.dat';

--
-- Data for Name: submissions; Type: TABLE DATA; Schema: public; Owner: sistadm_write
--

COPY public.submissions (id, user_id, department_code, batch_code, status, is_verified, is_admitted, application_id, merit_list_id, payment_id) FROM stdin;
\.
COPY public.submissions (id, user_id, department_code, batch_code, status, is_verified, is_admitted, application_id, merit_list_id, payment_id) FROM '$$PATH$$/3508.dat';

--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: sistadm_write
--

COPY public.users (id, name, email, password, phone, email_verified, phone_verified, role, application_id, is_active) FROM stdin;
\.
COPY public.users (id, name, email, password, phone, email_verified, phone_verified, role, application_id, is_active) FROM '$$PATH$$/3506.dat';

--
-- Name: academic_details_id_seq; Type: SEQUENCE SET; Schema: public; Owner: sistadm_write
--

SELECT pg_catalog.setval('public.academic_details_id_seq', 30, true);


--
-- Name: application_id_seq; Type: SEQUENCE SET; Schema: public; Owner: sistadm_write
--

SELECT pg_catalog.setval('public.application_id_seq', 44, true);


--
-- Name: basic_details_id_seq; Type: SEQUENCE SET; Schema: public; Owner: sistadm_write
--

SELECT pg_catalog.setval('public.basic_details_id_seq', 31, true);


--
-- Name: class_12_marks_id_seq; Type: SEQUENCE SET; Schema: public; Owner: sistadm_write
--

SELECT pg_catalog.setval('public.class_12_marks_id_seq', 1, false);


--
-- Name: diploma_id_seq; Type: SEQUENCE SET; Schema: public; Owner: sistadm_write
--

SELECT pg_catalog.setval('public.diploma_id_seq', 4, true);


--
-- Name: diploma_marks_id_seq; Type: SEQUENCE SET; Schema: public; Owner: sistadm_write
--

SELECT pg_catalog.setval('public.diploma_marks_id_seq', 1, false);


--
-- Name: documents_id_seq; Type: SEQUENCE SET; Schema: public; Owner: sistadm_write
--

SELECT pg_catalog.setval('public.documents_id_seq', 158, true);


--
-- Name: merit_list_id_seq; Type: SEQUENCE SET; Schema: public; Owner: sistadm_write
--

SELECT pg_catalog.setval('public.merit_list_id_seq', 19, true);


--
-- Name: merit_list_student_id_seq; Type: SEQUENCE SET; Schema: public; Owner: sistadm_write
--

SELECT pg_catalog.setval('public.merit_list_student_id_seq', 1, false);


--
-- Name: payment_transactions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: sistadm_write
--

SELECT pg_catalog.setval('public.payment_transactions_id_seq', 1, false);


--
-- Name: payments_id_seq; Type: SEQUENCE SET; Schema: public; Owner: sistadm_write
--

SELECT pg_catalog.setval('public.payments_id_seq', 77, true);


--
-- Name: school_id_seq; Type: SEQUENCE SET; Schema: public; Owner: sistadm_write
--

SELECT pg_catalog.setval('public.school_id_seq', 59, true);


--
-- Name: submission_id_seq; Type: SEQUENCE SET; Schema: public; Owner: sistadm_write
--

SELECT pg_catalog.setval('public.submission_id_seq', 39, true);


--
-- Name: users_id_seq; Type: SEQUENCE SET; Schema: public; Owner: sistadm_write
--

SELECT pg_catalog.setval('public.users_id_seq', 17, true);


--
-- Name: academic_details academic_details_pkey; Type: CONSTRAINT; Schema: public; Owner: sistadm_write
--

ALTER TABLE ONLY public.academic_details
    ADD CONSTRAINT academic_details_pkey PRIMARY KEY (id);


--
-- Name: applications applications_pkey; Type: CONSTRAINT; Schema: public; Owner: sistadm_write
--

ALTER TABLE ONLY public.applications
    ADD CONSTRAINT applications_pkey PRIMARY KEY (id);


--
-- Name: basic_details basic_details_pkey; Type: CONSTRAINT; Schema: public; Owner: sistadm_write
--

ALTER TABLE ONLY public.basic_details
    ADD CONSTRAINT basic_details_pkey PRIMARY KEY (id);


--
-- Name: batches batches_pkey; Type: CONSTRAINT; Schema: public; Owner: sistadm_write
--

ALTER TABLE ONLY public.batches
    ADD CONSTRAINT batches_pkey PRIMARY KEY (batch_code);


--
-- Name: class_12_marks class_12_marks_pkey; Type: CONSTRAINT; Schema: public; Owner: sistadm_write
--

ALTER TABLE ONLY public.class_12_marks
    ADD CONSTRAINT class_12_marks_pkey PRIMARY KEY (id);


--
-- Name: departments departments_pkey; Type: CONSTRAINT; Schema: public; Owner: sistadm_write
--

ALTER TABLE ONLY public.departments
    ADD CONSTRAINT departments_pkey PRIMARY KEY (department_code);


--
-- Name: diploma diploma_pkey; Type: CONSTRAINT; Schema: public; Owner: sistadm_write
--

ALTER TABLE ONLY public.diploma
    ADD CONSTRAINT diploma_pkey PRIMARY KEY (id);


--
-- Name: documents documents_pkey; Type: CONSTRAINT; Schema: public; Owner: sistadm_write
--

ALTER TABLE ONLY public.documents
    ADD CONSTRAINT documents_pkey PRIMARY KEY (id);


--
-- Name: merit_list_students merit_list_students_pkey; Type: CONSTRAINT; Schema: public; Owner: sistadm_write
--

ALTER TABLE ONLY public.merit_list_students
    ADD CONSTRAINT merit_list_students_pkey PRIMARY KEY (id);


--
-- Name: merit_lists merit_lists_pkey; Type: CONSTRAINT; Schema: public; Owner: sistadm_write
--

ALTER TABLE ONLY public.merit_lists
    ADD CONSTRAINT merit_lists_pkey PRIMARY KEY (id);


--
-- Name: payment_transactions payment_transactions_pkey; Type: CONSTRAINT; Schema: public; Owner: sistadm_write
--

ALTER TABLE ONLY public.payment_transactions
    ADD CONSTRAINT payment_transactions_pkey PRIMARY KEY (id);


--
-- Name: payments payments_pkey; Type: CONSTRAINT; Schema: public; Owner: sistadm_write
--

ALTER TABLE ONLY public.payments
    ADD CONSTRAINT payments_pkey PRIMARY KEY (id);


--
-- Name: school school_pkey; Type: CONSTRAINT; Schema: public; Owner: sistadm_write
--

ALTER TABLE ONLY public.school
    ADD CONSTRAINT school_pkey PRIMARY KEY (id);


--
-- Name: submissions submissions_pkey; Type: CONSTRAINT; Schema: public; Owner: sistadm_write
--

ALTER TABLE ONLY public.submissions
    ADD CONSTRAINT submissions_pkey PRIMARY KEY (id);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: sistadm_write
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: academic_details academic_details_class_10_school_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: sistadm_write
--

ALTER TABLE ONLY public.academic_details
    ADD CONSTRAINT academic_details_class_10_school_id_fkey FOREIGN KEY (class_10_school_id) REFERENCES public.school(id);


--
-- Name: academic_details academic_details_class_12_school_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: sistadm_write
--

ALTER TABLE ONLY public.academic_details
    ADD CONSTRAINT academic_details_class_12_school_id_fkey FOREIGN KEY (class_12_school_id) REFERENCES public.school(id);


--
-- Name: academic_details academic_details_diploma_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: sistadm_write
--

ALTER TABLE ONLY public.academic_details
    ADD CONSTRAINT academic_details_diploma_id_fkey FOREIGN KEY (diploma_id) REFERENCES public.diploma(id);


--
-- Name: applications applications_academic_details_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: sistadm_write
--

ALTER TABLE ONLY public.applications
    ADD CONSTRAINT applications_academic_details_id_fkey FOREIGN KEY (academic_details_id) REFERENCES public.academic_details(id);


--
-- Name: applications applications_basic_details_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: sistadm_write
--

ALTER TABLE ONLY public.applications
    ADD CONSTRAINT applications_basic_details_id_fkey FOREIGN KEY (basic_details_id) REFERENCES public.basic_details(id);


--
-- Name: applications applications_payment_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: sistadm_write
--

ALTER TABLE ONLY public.applications
    ADD CONSTRAINT applications_payment_id_fkey FOREIGN KEY (payment_id) REFERENCES public.payments(id);


--
-- Name: basic_details basic_details_identity_document_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: sistadm_write
--

ALTER TABLE ONLY public.basic_details
    ADD CONSTRAINT basic_details_identity_document_id_fkey FOREIGN KEY (identity_document_id) REFERENCES public.documents(id);


--
-- Name: batches batches_department_code_fkey; Type: FK CONSTRAINT; Schema: public; Owner: sistadm_write
--

ALTER TABLE ONLY public.batches
    ADD CONSTRAINT batches_department_code_fkey FOREIGN KEY (department_code) REFERENCES public.departments(department_code);


--
-- Name: class_12_marks class_12_marks_school_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: sistadm_write
--

ALTER TABLE ONLY public.class_12_marks
    ADD CONSTRAINT class_12_marks_school_id_fkey FOREIGN KEY (school_id) REFERENCES public.school(id);


--
-- Name: documents documents_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: sistadm_write
--

ALTER TABLE ONLY public.documents
    ADD CONSTRAINT documents_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: diploma fk1_diploma_document_id; Type: FK CONSTRAINT; Schema: public; Owner: sistadm_write
--

ALTER TABLE ONLY public.diploma
    ADD CONSTRAINT fk1_diploma_document_id FOREIGN KEY (document_id) REFERENCES public.documents(id);


--
-- Name: submissions fk1_submissions_applications; Type: FK CONSTRAINT; Schema: public; Owner: sistadm_write
--

ALTER TABLE ONLY public.submissions
    ADD CONSTRAINT fk1_submissions_applications FOREIGN KEY (application_id) REFERENCES public.applications(id);


--
-- Name: merit_list_students merit_list_students_merit_list_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: sistadm_write
--

ALTER TABLE ONLY public.merit_list_students
    ADD CONSTRAINT merit_list_students_merit_list_id_fkey FOREIGN KEY (merit_list_id) REFERENCES public.merit_lists(id);


--
-- Name: merit_list_students merit_list_students_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: sistadm_write
--

ALTER TABLE ONLY public.merit_list_students
    ADD CONSTRAINT merit_list_students_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: merit_lists merit_lists_batch_code_fkey; Type: FK CONSTRAINT; Schema: public; Owner: sistadm_write
--

ALTER TABLE ONLY public.merit_lists
    ADD CONSTRAINT merit_lists_batch_code_fkey FOREIGN KEY (batch_code) REFERENCES public.batches(batch_code);


--
-- Name: merit_lists merit_lists_department_code_fkey; Type: FK CONSTRAINT; Schema: public; Owner: sistadm_write
--

ALTER TABLE ONLY public.merit_lists
    ADD CONSTRAINT merit_lists_department_code_fkey FOREIGN KEY (department_code) REFERENCES public.departments(department_code);


--
-- Name: payment_transactions payment_transactions_payment_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: sistadm_write
--

ALTER TABLE ONLY public.payment_transactions
    ADD CONSTRAINT payment_transactions_payment_id_fkey FOREIGN KEY (payment_id) REFERENCES public.payments(id);


--
-- Name: school school_document_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: sistadm_write
--

ALTER TABLE ONLY public.school
    ADD CONSTRAINT school_document_id_fkey FOREIGN KEY (document_id) REFERENCES public.documents(id);


--
-- Name: submissions submissions_batch_code_fkey; Type: FK CONSTRAINT; Schema: public; Owner: sistadm_write
--

ALTER TABLE ONLY public.submissions
    ADD CONSTRAINT submissions_batch_code_fkey FOREIGN KEY (batch_code) REFERENCES public.batches(batch_code);


--
-- Name: submissions submissions_department_code_fkey; Type: FK CONSTRAINT; Schema: public; Owner: sistadm_write
--

ALTER TABLE ONLY public.submissions
    ADD CONSTRAINT submissions_department_code_fkey FOREIGN KEY (department_code) REFERENCES public.departments(department_code);


--
-- Name: submissions submissions_merit_list_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: sistadm_write
--

ALTER TABLE ONLY public.submissions
    ADD CONSTRAINT submissions_merit_list_id_fkey FOREIGN KEY (merit_list_id) REFERENCES public.merit_lists(id);


--
-- Name: submissions submissions_payment_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: sistadm_write
--

ALTER TABLE ONLY public.submissions
    ADD CONSTRAINT submissions_payment_id_fkey FOREIGN KEY (payment_id) REFERENCES public.payments(id);


--
-- Name: submissions submissions_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: sistadm_write
--

ALTER TABLE ONLY public.submissions
    ADD CONSTRAINT submissions_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: users users_application_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: sistadm_write
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_application_id_fkey FOREIGN KEY (application_id) REFERENCES public.applications(id);


--
-- Name: DATABASE sistadm; Type: ACL; Schema: -; Owner: postgres
--

GRANT ALL ON DATABASE sistadm TO sistadm_write;


--
-- Name: SCHEMA public; Type: ACL; Schema: -; Owner: postgres
--

GRANT USAGE ON SCHEMA public TO sistadm_write;


--
-- PostgreSQL database dump complete
--

